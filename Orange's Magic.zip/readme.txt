This is Orange's Magic, a mod that adds new secrets into Dwarf Fortress.

This mod introduces:

* Pyromancy - The powers of fire.
* Geomancy - The powers of earth.
* Hydromancy - The powers of water
* Aeromancy - The powers of air.

Coming soon:

* Mentalism - The power to attack the minds of enemies.

When extracting the .zip file, extract all files beginning with secret_ to Dwarf Fortress/raw/objects/text before extracting the rest of the files. After that, extract the rest of the files to Dwarf Fortress/raw/objects.

After this is finished, you have successfully installed the mod. Have fun!

-Orange

