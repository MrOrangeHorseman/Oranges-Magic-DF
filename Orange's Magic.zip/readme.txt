This is Orange's Magic, a mod that adds new secrets into Dwarf Fortress.

This mod introduces:

* Pyromancy - The powers of fire.
* Geomancy - The powers of earth.
* Hydromancy - The powers of water
* Aeromancy - The powers of air.
* Mentalism - The power to attack the minds of enemies.
* White magic - The powers of light and holiness.
* Black magic - The powers of darkness and evil.

When extracting the .zip file, extract all files beginning with secret_ to Dwarf Fortress/raw/objects/text before extracting the rest of the files. After that, extract the rest of the files to Dwarf Fortress/raw/objects. Do not extract this file or the "noted errors" file.

If you have a version of the mod before 0.1.3, delete creature_windman, inorganic_wind and material_template_wind from Dwarf Fortress/raw/objects.

After this is finished, you have successfully installed the mod. Have fun!

-Orange

